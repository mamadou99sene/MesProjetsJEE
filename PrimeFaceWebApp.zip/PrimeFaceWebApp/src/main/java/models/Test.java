package models;



public class Test {
public static void main(String [] args)
{
	//Personnes p=new PersonnesHome().findPersonnesByID(1);
	//System.out.println(p.getEmail());
}
}
